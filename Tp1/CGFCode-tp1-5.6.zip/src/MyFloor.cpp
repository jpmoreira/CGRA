#include "MyFloor.h"


void MyFloor::draw(){

	glPushMatrix();
	glTranslatef(-4, 0, -3);
	glScalef(8, 0.1, 6);
	glTranslatef(0.5, 0.5, 0.5);
	floor_cube.draw();
	glPopMatrix();
}