#include "MyFloor.h"

void MyFloor::draw(){

	//glTranslatef(-2.5, 0, -1.5);

	glTranslatef(-4, 0, -3);
	glScalef(8, 0.1, 6);
	glTranslatef(0.5, 0.5, 0.5);
	myCube->draw();
}