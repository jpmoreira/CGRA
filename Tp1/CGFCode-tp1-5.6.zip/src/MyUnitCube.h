#ifndef MYUNITCUBE_H
#define MYUNITCUBE_H

#include "CGFobject.h"

class MyUnitCube: public CGFobject {
	public:
		void draw();
};

#endif