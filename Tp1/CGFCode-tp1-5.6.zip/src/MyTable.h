#ifndef MYTABLE_H
#define MYTABLE_H

#include "CGFobject.h"
#include "MyUnitCube.h"


class MyTable: public CGFobject {
	public:
		MyUnitCube myCube;
		void draw();
};

#endif