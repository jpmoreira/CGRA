#ifndef MYFLOOR_H
#define MYFLOOR_H

#include "MyUnitCube.h"
#include "CGFobject.h"


class MyFloor: public CGFobject{
public:
	MyUnitCube floor_cube;
	void draw();
};

#endif