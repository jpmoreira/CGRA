#ifndef MYFLOOR_H
#define MYFLOOR_H

#include "CGFobject.h"
#include "MyUnitCube.h"


class MyFloor: public CGFobject {
	public:
		MyUnitCube *myCube;
		void draw();
};

#endif