#include "MyTable.h"

void MyTable::draw(){

	glTranslatef(-2.5, 0, -1.5);

	//left-back leg
	glPushMatrix(); 
	glScalef(0.15, 3.5, 0.15);
	glTranslatef(0.5, 0.5, 0.5);
	myCube.draw();
	glPopMatrix();

	//right-back leg
	glPushMatrix();
	glTranslatef(4.7, 0 , 0);
	glScalef(0.15, 3.5, 0.15);
	glTranslatef(0.5, 0.5, 0.5);
	myCube.draw();
	glPopMatrix();

	//left-front leg
	glPushMatrix();
	glTranslatef(0, 0, 2.7);
	glScalef(0.15, 3.5, 0.15);
	glTranslatef(0.5, 0.5, 0.5);
	myCube.draw();
	glPopMatrix();

	//right-front leg
	glPushMatrix();
	glTranslatef(4.7, 0, 2.7);
	glScalef(0.15, 3.5, 0.15);
	glTranslatef(0.5, 0.5, 0.5);
	myCube.draw();
	glPopMatrix();

	//surface
	glPushMatrix();
	glTranslatef(0, 3.5, 0);
	glScalef(5, 0.3, 3);
	glTranslatef(0.5, 0.5, 0.5);
	myCube.draw();
	glPopMatrix();

}