#ifndef TPSCENE_H
#define TPSCENE_H

#include "CGFscene.h"
#include "ExampleObject.h"
#include "MyTable.h"
#include "MyFloor.h"

class TPscene : public CGFscene
{
public:
	void init();
	void display();
	ExampleObject * myObject;
	MyTable * myTable;
	MyFloor  myFloor;

};

#endif