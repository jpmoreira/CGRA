#include "MyUnitCube.h"

void MyUnitCube::draw() 
{
	//back
	glPushMatrix();
	glTranslated(0, 0, -0.5);
	glRectf(-0.5, 0.5, 0.5, -0.5);
	glPopMatrix();

	//left
	glPushMatrix();
	glRotatef(90, 0, 1, 0);
	glTranslated(0, 0, -0.5);
	glRectf(-0.5, 0.5, 0.5, -0.5);
	glPopMatrix();

	//right
	glPushMatrix();
	glRotatef(-90, 0, 1, 0);
	glTranslated(0, 0, -0.5);
	glRectf(-0.5, 0.5, 0.5, -0.5);
	glPopMatrix();

	//front
	glPushMatrix();
	glTranslated(0, 0, 0.5);
	glRectf(-0.5, -0.5, 0.5, 0.5);
	glPopMatrix();

	//top
	glPushMatrix();
	glTranslatef(0, 0.5, 0);
	glRotatef(-90, 1, 0, 0);
	glRectf(-0.5, -0.5, 0.5, 0.5);
	glPopMatrix();

	//bottom
	glPushMatrix();
	glTranslatef(0, -0.5, 0);
	glRotatef(-90, 1, 0, 0);
	glRectf(0.5, -0.5, -0.5, 0.5);
	glPopMatrix();



	
	/*
	Wrong way to do it
	//bottom
	glBegin(GL_QUADS);
	glVertex3d(-1, 0, -1);
	glVertex3d(-1, 0,  1);
	glVertex3d( 1, 0,  1);
	glVertex3d( 1, 0, -1);
	glEnd();

	//left
	glBegin(GL_QUADS); 
	glVertex3d(-1, 0, -1);
	glVertex3d(-1, 0,  1);
	glVertex3d(-1, 1,  1);
	glVertex3d(-1, 1, -1);
	glEnd();

	//right
	glBegin(GL_QUADS); 
	glVertex3d(-1, 0, -1);
	glVertex3d(1, 0,  1);
	glVertex3d(1, 1,  1);
	glVertex3d(1, 1, -1);
	glEnd();

	//front
	glBegin(GL_QUADS); 
	glVertex3d(-1, 0,  1);
	glVertex3d( 1, 0,  1);
	glVertex3d( 1, 1,  1);
	glVertex3d(-1, 1,  1);
	glEnd();

	//back
	glBegin(GL_QUADS); 
	glVertex3d(-1, 0, -1);
	glVertex3d( 1, 0, -1);
	glVertex3d( 1, 1, -1);
	glVertex3d(-1, 1, -1);
	glEnd();

	//top
	glBegin(GL_QUADS);
	glVertex3d(-1, 1, -1);
	glVertex3d(-1, 1,  1);
	glVertex3d( 1, 1,  1);
	glVertex3d( 1, 1, -1);
	glEnd();
	*/
}